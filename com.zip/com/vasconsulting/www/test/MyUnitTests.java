package com.vasconsulting.www.test;

public class MyUnitTests
{

}
