package com.vasconsulting.www.test;

import java.rmi.RemoteException;
import java.util.ArrayList;

import com.vasconsulting.www.utility.BillingPlanObjectUtility;
import com.vasconsulting.www.utility.XMLUtility;

import ws.its.tabs.webservices.TBI_KPI_PKG.TBI_KPI_PKG_wsdl.TBI_KPI_PKGProxy;
import ws.its.tabs.webservices.TBI_KPI_PKG.TBI_KPI_PKG_wsdl.types.GetPreOrPostPaidElement;
import ws.its.tabs.webservices.TBI_KPI_PKG.TBI_KPI_PKG_wsdl.types.GetPreOrPostPaidResponseElement;
import ws.its.tabs.webservices.TBI_KPI_PKG.TBI_KPI_PKG_wsdl.types.GetSubscriberInformationElement;
import ws.its.tabs.webservices.TBI_KPI_PKG.TBI_KPI_PKG_wsdl.types.GetSubscriberInformationResponseElement;
import ws.its.tabs.webservices.ordermangement.OrderManagement_wsdl.OrderManagementProxy;
import ws.its.tabs.webservices.ordermangement.OrderManagement_wsdl.types.ChangeserviceElement;

public class MainTestDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		XMLUtility ut = new XMLUtility();
		//ArrayList<BillingPlanObjectUtility> te =ut.loadApplicationConfigurationXML();
		/*String ussd = "<ussd><msisdn>2348087616915</msisdn><type>1</type><msg>Nah Testooooooo</msg></ussd>";
		System.out.println(ut.getAtosUSSDXmlAsMap(ussd));System.exit(0);*/
		/*String ussd = "Please press\n 1. Prepaid Blackberry\n 2. Postpaid Blackberry.";
		System.out.println(ut.generateAtosResponse(ussd, 2));System.exit(0);*/
		String ussd = "Please press\n 1. Prepaid Blackberry\n 2. Postpaid Blackberry.";
		System.out.println(ut.generateHomiscoResponse("123456", "1",ussd, "REQUEST"));System.exit(0);
		
		//System.out.println(te.get(0).getCoomandObjects().get(0).getCommand());
		System.out.println(ut.getUSSDMessage("prepblackberrybesdailymenuleaf"));
		System.exit(0);
		
		GetPreOrPostPaidResponseElement respParamters = null;
		
		//retrieve the type of SUB- pre or paid
		GetSubscriberInformationResponseElement respParameters1 = null;
		
		/*GetSubscriberInformationElement parameters1 = new GetSubscriberInformationElement();
		parameters1.setSubno("8022229385");*/
		
		//retrieve sub IMSI
		/*GetPreOrPostPaidElement parameters = new GetPreOrPostPaidElement();
		parameters.setSubno("8120504561");
		parameters.setArea("0");
		parameters.setSubscrType("G");
		TBI_KPI_PKGProxy proxy = new TBI_KPI_PKGProxy();*/
		try {
			//respParameters1 = proxy.getSubscriberInformation(parameters1);
			//respParamters = proxy.getPreOrPostPaid(parameters);
			//System.out.println(respParameters1.getResult());
			/*System.out.println(new XMLUtility().getSubscriberType(respParameters1.getResult()));*/
			
			//System.out.println(respParamters.getResult());
			
			//System.out.println(new XMLUtility().processTABSResponse(respParamters.getResult()));
			
			ChangeserviceElement params = new ChangeserviceElement();
			params.setPSubno("8125718585");
			params.setPUsername("BBERY_SV");
			params.setPSubscrtype("G");
			params.setPArea("0");
			params.setPSubsidyFlag("N");
			params.setPSndcmd("Y");
			
			String serviceName = "<Service name=\"OrderManagement\" msgType=\"Input\"><Operation name=\"op1\" paramName=\"service\">"+
"<InputParams><SServiceList><SService><Action>D</Action><EquipID>APN38</EquipID><LoginId/><SerialNo/><SParamList><SParam><ParamName>"+
"</ParamName><ParamValue></ParamValue></SParam></SParamList></SService></SServiceList></InputParams></Operation></Service>";
			
			params.setPServices(serviceName);
			params.setPAdditonalparams("<?xml version=\"1.0\" encoding=\"UTF-8\"?><SParamList></SParamList>");
			
			OrderManagementProxy proxy1 = new OrderManagementProxy();
			System.out.println(proxy1.changeservice(params).getResult());
			
			
			//System.out.println(new XMLUtility().processTABSResponse(respParameters1.getResult()));
			//System.out.println(new XMLUtility().getSubscriberType(respParamters.getResult()));
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
