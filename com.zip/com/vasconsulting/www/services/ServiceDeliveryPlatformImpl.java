package com.vasconsulting.www.services;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.GregorianCalendar;

import javax.jws.WebService;

import org.apache.log4j.Logger;

import com.vasconsulting.www.domain.ActivityLogger;
import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.domain.TransactionLog;
import com.vasconsulting.www.interfaces.HibernateUtility;
import com.vasconsulting.www.invokers.CommandFactory;
import com.vasconsulting.www.invokers.CommandInvoker;
import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.utility.BillingPlanObjectUtility;
import com.vasconsulting.www.utility.CommandPropertiesUtility;
import com.vasconsulting.www.utility.LoadAllBillingPlanObjects;
import com.vasconsulting.www.utility.LoadAllProperties;
import com.vasconsulting.www.utility.RIMQueryUtil;
import com.vasconsulting.www.utility.SendSmsToKannelService;
import com.vasconsulting.www.utility.StatusCodes;

@WebService(endpointInterface = "com.vasconsulting.www.services.ServiceDeliveryPlatform")
public class ServiceDeliveryPlatformImpl implements ServiceDeliveryPlatform
{
	private HibernateUtility hibernateUtility;
	private LoadAllBillingPlanObjects allBillingPlans;
	private ArrayList<BillingPlanObjectUtility> billingPlans;
	private Logger logger = Logger.getLogger(ServiceDeliveryPlatformImpl.class);
	private GregorianCalendar calendar = new GregorianCalendar();
	private RIMQueryUtil rimQueryUtility;
	
	private CommandInvoker commandInvoker;
	private CommandFactory commandFactory;
	
	private SendSmsToKannelService smsService;
	private LoadAllProperties properties;
	
	public void setProperties(LoadAllProperties properties)
	{
		this.properties = properties;
	}
	
	public void setSmsService(SendSmsToKannelService smsService)
	{
		this.smsService = smsService;
	}
	
	public void setRimQueryUtility(RIMQueryUtil rimQueryUtility)
	{
		this.rimQueryUtility = rimQueryUtility;
	}

	public void setCommandFactory(CommandFactory commandFactory)
	{
		this.commandFactory = commandFactory;
	}
		
	public void setCommandInvoker(CommandInvoker commandInvoker)
	{
		this.commandInvoker = commandInvoker;
	}
	
	public void setAllBillingPlans(LoadAllBillingPlanObjects allBillingPlans)
	{
		this.allBillingPlans = allBillingPlans;
	}

	public void setHibernateUtility(HibernateUtility hibernateUtility)
	{
		this.hibernateUtility = hibernateUtility;
	}

	public SubscriberDetail getSubscriberDetails(String prameter, String parameterValue)
	{
		return this.hibernateUtility.getSubscriberInformation(prameter, parameterValue);
	}

	public Collection<TransactionLog> getSubscriberTransactionLog(String msisdn)
	{
		return hibernateUtility.getSubscriberTransactionLog(msisdn);
	}
	
	public void getSubscriberLastProvisioningActions()
	{
		// TODO Auto-generated method stub

	}

	public int provisionSubscriber(String msisdn, String message)
	{
		return StatusCodes.INVALID_MESSAGE;
	}
	
	public int provisionPrepBBSubscriber(SubscriberDetail subscriber, String billingPlan)
	{
		try
		{
			if (subscriber.getMsisdn().equalsIgnoreCase(""))return StatusCodes.OTHER_ERRORS;
			billingPlans = allBillingPlans.getAllBillingPlans();	
			
			int provisionStatus = -1;
			
			for (BillingPlanObjectUtility billingPlanObjectUtility : billingPlans) {
				
				if (billingPlanObjectUtility.getShortCode().trim().equalsIgnoreCase(billingPlan.trim()))
				{
					logger.info("Billing Plan match found for shortcode : "+billingPlan+
							" from subscriber "+subscriber.getMsisdn());
					logger.info("=====Setting up the subscriber and the selected plan in Session=====");
					
					BillingPlanObjectUtility billingPlanObjectLive = (BillingPlanObjectUtility)ContextLoaderImpl.getBeans("billingPlanObject");				
					billingPlanObjectLive.setCost(billingPlanObjectUtility.getCost());
					billingPlanObjectLive.setStatus(billingPlanObjectUtility.getStatus());
					billingPlanObjectLive.setDescription(billingPlanObjectUtility.getDescription());
					billingPlanObjectLive.setExternalData(billingPlanObjectUtility.getExternalData());
					billingPlanObjectLive.setShortCode(billingPlanObjectUtility.getShortCode());
					billingPlanObjectLive.setSuccessMessage(billingPlanObjectUtility.getSuccessMessage());
					billingPlanObjectLive.setValidity(billingPlanObjectUtility.getValidity());
					billingPlanObjectLive.setCoomandObjects(billingPlanObjectUtility.getCoomandObjects());
					
					SubscriberDetail subscriberDetail = (SubscriberDetail)ContextLoaderImpl.getBeans("subscriberDetail");
					subscriberDetail.setMsisdn(subscriber.getMsisdn());
					subscriberDetail.setLast_subscription_date(calendar);
					subscriberDetail.setDate_created(calendar);
					subscriberDetail.setServicetype(new Integer(billingPlanObjectUtility.getValidity()).intValue());
					subscriberDetail.setNext_subscription_date(getDateOfMonth(subscriberDetail.getServicetype()));
					subscriberDetail.setFirstname(subscriber.getFirstname());
					subscriberDetail.setMiddlename(subscriber.getMiddlename());
					subscriberDetail.setLastname(subscriber.getLastname());
					subscriberDetail.setEmail(subscriber.getEmail());
					subscriberDetail.setPin(subscriber.getPin());
					subscriberDetail.setImei(subscriber.getImei());
					
					subscriberDetail.setShortCode(subscriber.getShortCode());					
					subscriberDetail.setAutoRenew(1);
					
					
					logger.info("======Finalized setup=======");
					
					ArrayList<CommandPropertiesUtility> commandProperties = billingPlanObjectUtility.getCoomandObjects();
					
					commandInvoker = new CommandInvoker();
					
					for (CommandPropertiesUtility commandProps : commandProperties)
					{
						commandInvoker.addCommand(commandFactory.GetCommandInstance(commandProps.getCommand(), "com.vasconsulting.www.interfaces.impl", 
								commandProps.getParam()));					
					}
					
					provisionStatus = commandInvoker.provision();
					
					logger.info("Provision request result is "+provisionStatus+" for subscriber with MSISDN = "+subscriber.getMsisdn());				
					
					if (provisionStatus != StatusCodes.SUCCESS)
					{
						smsService.sendMessageToKannel(properties.getProperty(new Integer(provisionStatus).toString()), subscriber.getMsisdn());
						logger.error("The request to provision "+subscriber.getMsisdn()+" failed with code "+provisionStatus);
						/**
						 * TODO:
						 * Implement what should be done in case of error/success.
						 */					
					}
					else
					{
						smsService.sendMessageToKannel(billingPlanObjectUtility.getSuccessMessage(), subscriber.getMsisdn());
						
					}
					return provisionStatus;
				}
			}
			return StatusCodes.INVALID_MESSAGE;
		
		}
		catch(Exception ex)
		{
			logger.info("There was a general failure in the processing of this subscriber "+subscriber.getMsisdn()+". Please check subscriber " +
					"details and manually process if applicable or try again.");
			ex.printStackTrace();
			/**
			 * TODO:
			 * Implement what should be done in case of error/success.
			 */	
			return StatusCodes.OTHER_ERRORS;
		}
		
	
	}

	public int provisionBBSubscriber(SubscriberDetail subscriber, String billingPlan)
	{
		try
		{
			if (subscriber.getMsisdn().equalsIgnoreCase("")) return StatusCodes.OTHER_ERRORS;
			billingPlans = allBillingPlans.getAllBillingPlans();	
			
			int provisionStatus = -1;
			
			for (BillingPlanObjectUtility billingPlanObjectUtility : billingPlans) {
				
				if (billingPlanObjectUtility.getShortCode().trim().equalsIgnoreCase(billingPlan.trim()))
				{
					logger.info("Billing Plan match found for shortcode : "+billingPlan+
							" from subscriber "+subscriber.getMsisdn());
					logger.info("=====Setting up the subscriber and the selected plan in Session=====");
					
					BillingPlanObjectUtility billingPlanObjectLive = (BillingPlanObjectUtility)ContextLoaderImpl.getBeans("billingPlanObject");				
					billingPlanObjectLive.setCost(billingPlanObjectUtility.getCost());
					billingPlanObjectLive.setStatus(billingPlanObjectUtility.getStatus());
					billingPlanObjectLive.setDescription(billingPlanObjectUtility.getDescription());
					billingPlanObjectLive.setExternalData(billingPlanObjectUtility.getExternalData());
					billingPlanObjectLive.setShortCode(billingPlanObjectUtility.getShortCode());
					billingPlanObjectLive.setSuccessMessage(billingPlanObjectUtility.getSuccessMessage());
					billingPlanObjectLive.setValidity(billingPlanObjectUtility.getValidity());
					billingPlanObjectLive.setCoomandObjects(billingPlanObjectUtility.getCoomandObjects());
					
					SubscriberDetail subscriberDetail = (SubscriberDetail)ContextLoaderImpl.getBeans("subscriberDetail");
					subscriberDetail.setMsisdn(subscriber.getMsisdn());
					subscriberDetail.setLast_subscription_date(calendar);
					subscriberDetail.setDate_created(calendar);
					subscriberDetail.setServicetype(new Integer(billingPlanObjectUtility.getValidity()).intValue());
					subscriberDetail.setNext_subscription_date(getLastDateOfMonth());
					subscriberDetail.setFirstname(subscriber.getFirstname());
					subscriberDetail.setMiddlename(subscriber.getMiddlename());
					subscriberDetail.setLastname(subscriber.getLastname());
					subscriberDetail.setEmail(subscriber.getEmail());
					subscriberDetail.setPin(subscriber.getPin());
					subscriberDetail.setImei(subscriber.getImei());
					
					subscriberDetail.setShortCode(subscriber.getShortCode());					
					subscriberDetail.setAutoRenew(1);
					
					
					logger.info("======Finalized setup=======");
					
					ArrayList<CommandPropertiesUtility> commandProperties = billingPlanObjectUtility.getCoomandObjects();
					
					commandInvoker = new CommandInvoker();
					
					for (CommandPropertiesUtility commandProps : commandProperties)
					{
						commandInvoker.addCommand(commandFactory.GetCommandInstance(commandProps.getCommand(), "com.vasconsulting.www.interfaces.impl", 
								commandProps.getParam()));					
					}
					
					provisionStatus = commandInvoker.provision();
					
					logger.info("Provision request result is "+provisionStatus+" for subscriber with MSISDN = "+subscriber.getMsisdn());				
					
					if (provisionStatus != StatusCodes.SUCCESS)
					{
						smsService.sendMessageToKannel(properties.getProperty(new Integer(provisionStatus).toString()), subscriber.getMsisdn());
						logger.error("The request to provision "+subscriber.getMsisdn()+" failed with code "+provisionStatus);
						/**
						 * TODO:
						 * Implement what should be done in case of error/success.
						 */					
					}
					else
					{
						smsService.sendMessageToKannel(billingPlanObjectUtility.getSuccessMessage(), subscriber.getMsisdn());
						
					}
					return provisionStatus;
				}
			}
			return StatusCodes.INVALID_MESSAGE;
		
		}
		catch(Exception ex)
		{
			logger.info("There was a general failure in the processing of this subscriber "+subscriber.getMsisdn()+". Please check subscriber " +
					"details and manually process if applicable or try again.");
			ex.printStackTrace();
			/**
			 * TODO:
			 * Implement what should be done in case of error/success.
			 */	
			return StatusCodes.OTHER_ERRORS;
		}
		
	}

	public int suspendBBSubscriber(String msisdn, String message)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	public int resumeBBSubscriber(String msisdn, String message)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	public int deProvisionBBSubscriber(SubscriberDetail subscriber)
	{
		try {
			//HibernateUtil hibernateUtil = new HibernateUtil();
			SubscriberDetail sub = hibernateUtility.getSubscriberInformation("msisdn", subscriber.getMsisdn());

			if (sub == null)
				return StatusCodes.NO_SUBSCRIBER_FOUND_WITH_DETAILS;
			if ("Deactivated".equals(sub.getStatus()))
				return StatusCodes.SUBCRIBER_IS_NOT_ON_LEGAL_STATE;

			//RIMQueryUtil rimUtility = new RIMQueryUtil();
			int rimRespCode = rimQueryUtility.cancelSubscription(subscriber);
			logger.info("Value from calling RIM is = " + rimRespCode);
			if (rimRespCode == 0
					|| (rimRespCode >= 21000 && rimRespCode <= 21500)) {

				sub.setStatus("Deactivated");
				if (hibernateUtility.updateSubscriberDetail(sub) == 0) {
					smsService.sendMessageToKannel(properties
							.getProperty("SuccessfulDeactivationMessage"),
							subscriber.getMsisdn());
					return StatusCodes.SUCCESS;
				} else {
					return StatusCodes.OTHER_ERRORS;
				}
			} else {
				return rimRespCode;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return StatusCodes.OTHER_ERRORS;
		}
	}

	public int modifyBBSubscriberNonBillingIdentifier(SubscriberDetail subscriber)
	{
		if (!"".equals(subscriber.getImsi()) || !"".equals(subscriber.getMsisdn())){
			int rimStatus = rimQueryUtility.modifySubscription(subscriber);
			
			if (rimStatus == 0 || (rimStatus >= 21000 && rimStatus <= 21500)){				
				int hibernateStatus = hibernateUtility.updateSubscriberDetail(subscriber);
				if (hibernateStatus != 0){
					//TODO: Implement code that will notify an administrator of failure
				}
				//Log this transaction to table
				TransactionLog transactionLog = new TransactionLog();
				
				transactionLog.setDate_created(new GregorianCalendar());
				transactionLog.setDescription("Non-billing ID SWAP");
				transactionLog.setMsisdn(subscriber.getMsisdn());
				transactionLog.setStatus(subscriber.getStatus());
				transactionLog.setService(subscriber.getServiceplan());
				
				hibernateUtility.saveTransactionlog(transactionLog);
				return StatusCodes.SUCCESS;
			}
			else return StatusCodes.OTHER_ERRORS;
		}
		else return StatusCodes.IMSI_AND_MSISDN_CANNOT_BE_EMPTY;
	}

	public int modifyBBSubscriberBillingIdentifier(SubscriberDetail subscriber, String newImsi)
	{
		if (!"".equals(subscriber.getImsi()) || !"".equals(newImsi)){
			if ("Active".equals(subscriber.getStatus())){
				int rimStatus = rimQueryUtility.modifySubscriptionIMSI(subscriber, newImsi);
				
				if (rimStatus == 0 || (rimStatus >= 21000 && rimStatus <= 21500)){
					subscriber.setImsi(newImsi);
					int hibernateStatus = hibernateUtility.updateSubscriberDetail(subscriber);
					if (hibernateStatus != 0){
						//TODO -- Implement log that will notify an administrator.
					}
					//Log this transaction to table
					TransactionLog transactionLog = new TransactionLog();
					transactionLog.setDate_created(new GregorianCalendar());
					transactionLog.setDescription("IMSI SWAP");
					transactionLog.setMsisdn(subscriber.getMsisdn());
					
					hibernateUtility.saveTransactionlog(transactionLog);
					
					return StatusCodes.SUCCESS;
				}
				else return rimStatus;
			}
			else return StatusCodes.SUBCRIBER_IS_NOT_ON_LEGAL_STATE;
		}
		else return StatusCodes.IMSI_AND_MSISDN_CANNOT_BE_EMPTY;
	}

	public int modifyBBSubscriberDemographicDetails(SubscriberDetail subscriber)
	{
		if (!"".equals(subscriber.getImsi()) || !"".equals(subscriber.getMsisdn())){
			return hibernateUtility.updateSubscriberDetail(subscriber);
		}
		else return StatusCodes.IMSI_AND_MSISDN_CANNOT_BE_EMPTY;
	}

	public ArrayList<BillingPlanObjectUtility> loadBillingPlan()
	{
		logger.info("Request to get all billing plans has been received.");
		return allBillingPlans.getAllBillingPlans();
	}

	/**
	 * This method is used to get the next subscription date of a subscribers lifecycle based on the supplied validity.
	 * @param noOfDays
	 * @return
	 */
	private GregorianCalendar getNextSubscriptionDate(int noOfDays){
		GregorianCalendar calendar1 = new GregorianCalendar();
		calendar1.add(GregorianCalendar.DAY_OF_MONTH, new Integer(noOfDays).intValue());
		return calendar1;
	}
	
	/**
	 * This method is used to get the last day of the month.
	 * @param noOfDays
	 * @return
	 */
	private GregorianCalendar getLastDateOfMonth(){
		GregorianCalendar calendar  = new GregorianCalendar();
		int dayOfMonth  = calendar.getActualMaximum(GregorianCalendar.DAY_OF_MONTH);
		
		int daysToAdd = dayOfMonth - calendar.get(GregorianCalendar.DAY_OF_MONTH);
		
		calendar.add(GregorianCalendar.DAY_OF_MONTH, daysToAdd);	
		return calendar;
	}
	
	private GregorianCalendar getDateOfMonth(int numberOfDays){
		GregorianCalendar calendar  = new GregorianCalendar();
		
		calendar.add(GregorianCalendar.DAY_OF_MONTH, numberOfDays);	
		return calendar;
	}

	public int logService(ActivityLogger log)
	{
		logger.info("Request to save all audit request has been received.");
		return hibernateUtility.logService(log);
	}	
	
	public ArrayList<SubscriberDetail> createReportTabular(String reportName)
	{
		if (reportName.equalsIgnoreCase("dailyrenewreport"))
		{
			return hibernateUtility.getRenewalReportTabular();
		}
		else if (reportName.equalsIgnoreCase("monthlycreatereport"))
		{
			return hibernateUtility.getActivationReportTabular(30);
		}
		else if (reportName.equalsIgnoreCase("weeklycreatereport"))
		{
			return hibernateUtility.getActivationReportTabular(7);
		}
		else
		{
			return hibernateUtility.getActivationReportTabular(1);
		}
	}
	
	public int createReportSumation(String reportName)
	{
		if (reportName.equalsIgnoreCase("dailyrenewreport"))
		{
			return hibernateUtility.getReportSumation("next_subscription_date", 1);
		}		
		else if (reportName.equalsIgnoreCase("monthlycreatereport"))
		{
			return hibernateUtility.getReportSumation("date_created", 30);
		}
		else if (reportName.equalsIgnoreCase("weeklycreatereport"))
		{
			return hibernateUtility.getReportSumation("date_created", 7);
		}
		else
		{
			return hibernateUtility.getReportSumation("date_created", 1);
		}
	}
		
}
