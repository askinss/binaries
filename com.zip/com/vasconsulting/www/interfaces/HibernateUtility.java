package com.vasconsulting.www.interfaces;

import java.util.ArrayList;
import java.util.Collection;

import com.vasconsulting.www.domain.ActivityLogger;
import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.domain.TransactionLog;

public interface HibernateUtility
{
	public int saveSubscriber(SubscriberDetail subscriberDetail);
	public int saveTransactionlog(TransactionLog transactionLog);
	public Collection<SubscriberDetail> getSubscriberInformation(SubscriberDetail subscriberDetail);
	public SubscriberDetail getSubscriberInformation(String param, String paramValue);
	public String getSubscriberTABSCreditLimit(String msisdn);
	public int updateSubscriberDetail(SubscriberDetail subscriebrDetail);
	public Collection<TransactionLog> getSubscriberTransactionLog(String msisdn);
	public Collection<SubscriberDetail> loadAllSubscriberDetails();
	public Collection<SubscriberDetail> loadAllSubscriberDetailsDueForActivation();
	public int logService(ActivityLogger logger);
	public int getReportSumation(String columnName, int daysToRetrieve);
	public ArrayList<SubscriberDetail> getRenewalReportTabular();
	public ArrayList<SubscriberDetail> getActivationReportTabular(int daysToRetrieve);
	public ArrayList<SubscriberDetail> getSubscribersExpiringSoon(int noOfDays);
}
