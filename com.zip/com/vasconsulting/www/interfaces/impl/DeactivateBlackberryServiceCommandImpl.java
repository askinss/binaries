package com.vasconsulting.www.interfaces.impl;

import java.util.GregorianCalendar;

import org.apache.log4j.Logger;

import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.domain.TransactionLog;
import com.vasconsulting.www.interfaces.Command;
import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.utility.BillingPlanObjectUtility;
import com.vasconsulting.www.utility.HibernateUtilityImpl;
import com.vasconsulting.www.utility.RIMQueryUtil;

public class DeactivateBlackberryServiceCommandImpl implements Command {
	private RIMQueryUtil rimUtility;
	private int rimStatus;
	private SubscriberDetail subscriberDetail;
	private TransactionLog transactionLog;
	private HibernateUtilityImpl hibernateUtility;
	private BillingPlanObjectUtility billingPlanObjectLive;
	private String receiverParams;
	private String [] receiverParamsValues;
	private Logger logger = Logger.getLogger(DeactivateBlackberryServiceCommandImpl.class);
	
	public int execute() {
		/**
		 * Load the spring managed beans from the context.
		 */
		rimUtility = 
			(RIMQueryUtil)ContextLoaderImpl.getBeans("rimUtility");		
		hibernateUtility = 
			(HibernateUtilityImpl)ContextLoaderImpl.getBeans("hibernateUtility");		
		subscriberDetail = 
			(SubscriberDetail)ContextLoaderImpl.getBeans("subscriberDetail");
		billingPlanObjectLive = 
			(BillingPlanObjectUtility)ContextLoaderImpl.getBeans("billingPlanObject");
		
		logger.info("Execute called on DeactivateBlackberryServiceCommandImpl for subscriber with msisdn "+subscriberDetail.getMsisdn());
		
		receiverParamsValues = receiverParams.split(",");
		
		subscriberDetail.setServiceplan(receiverParamsValues[0]);
		
		rimStatus = rimUtility.cancelSubscription(subscriberDetail);
		
		transactionLog = new TransactionLog();
		transactionLog.setDate_created(new GregorianCalendar());
		transactionLog.setDescription("DEACTIVATE BB");
		transactionLog.setMsisdn(subscriberDetail.getMsisdn());
		transactionLog.setService(subscriberDetail.getServiceplan());
		transactionLog.setShortcode(billingPlanObjectLive.getShortCode());
		
		if (rimStatus == 0 || (rimStatus >= 21000 && rimStatus <= 25000)) 
		{
			transactionLog.setStatus("Successful");
			rimStatus = 0;
			logger.info("Deactivate call on "+subscriberDetail.getMsisdn()+" returned "+rimStatus+". This is okay! proceeding.");
		}
		else 
		{
			transactionLog.setShortcode("FAILED");
			logger.info("Deactivate call on "+subscriberDetail.getMsisdn()+" returned "+rimStatus);
		}
		
		hibernateUtility.saveTransactionlog(transactionLog);
		
		return rimStatus;
	}

	public int logTransaction()
	{
		return 0;
	}

	public void setReceiverParameters(String receiverParams)
	{
		this.receiverParams = receiverParams; 		
	}

}
