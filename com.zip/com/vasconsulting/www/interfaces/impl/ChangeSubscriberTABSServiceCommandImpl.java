package com.vasconsulting.www.interfaces.impl;

import java.rmi.RemoteException;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;

import ws.its.tabs.webservices.ordermangement.OrderManagement_wsdl.OrderManagementProxy;
import ws.its.tabs.webservices.ordermangement.OrderManagement_wsdl.types.ChangeserviceElement;
import ws.its.tabs.webservices.ordermangement.OrderManagement_wsdl.types.ChangeserviceResponseElement;

import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.domain.TransactionLog;
import com.vasconsulting.www.interfaces.Command;
import com.vasconsulting.www.interfaces.HibernateUtility;
import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.utility.LoadAllProperties;
import com.vasconsulting.www.utility.StatusCodes;
import com.vasconsulting.www.utility.XMLUtility;

public class ChangeSubscriberTABSServiceCommandImpl implements Command {
	private HibernateUtility hibernateUtility;
	private SubscriberDetail subscriberDetail;
	private ChangeserviceResponseElement responseElement;
	XMLUtility xmlUtility = new XMLUtility();
	private OrderManagementProxy orderProxy = new OrderManagementProxy();
	private LoadAllProperties properties;
	private Logger logger = Logger.getLogger(ChangeSubscriberTABSServiceCommandImpl.class);
	private String []receiverParams;
	private String receiverParam;
	private TransactionLog transactionlog;
	
		
	public int execute() {
		/**
		 * Retrieve the spring managed beans from the container.
		 */
		subscriberDetail = 
			(SubscriberDetail)ContextLoaderImpl.getBeans("subscriberDetail");		
		hibernateUtility = 
			(HibernateUtility)ContextLoaderImpl.getBeans("hibernateUtility");
		properties = 
			(LoadAllProperties)ContextLoaderImpl.getBeans("loadProperties");
		
		logger.info("Execute called on ChangeSubscriberTABSServiceCommandImpl for subscriber with MSISDN = "+subscriberDetail.getMsisdn());
		
		receiverParams = receiverParam.split(",");
		
		if (receiverParams.length != 2) return StatusCodes.WRONG_SERVICEVALUE_FORMAT;
		
		ChangeserviceElement params = new ChangeserviceElement();
		params.setPSubno(stripLeadingMsisdnPrefix(subscriberDetail.getMsisdn()));
		params.setPUsername(properties.getProperty("tabschangeserviceusername"));//dynamic from props file
		params.setPSubscrtype("G");
		params.setPArea("0");
		params.setPSubsidyFlag("N");
		params.setPSndcmd("Y");
		
		String serviceName = "<Service name=\"OrderManagement\" msgType=\"Input\"><Operation name=\"op1\" paramName=\"service\">"+
			"<InputParams><SServiceList><SService><Action>"+receiverParams[0]+"</Action><EquipID>"+receiverParams[1]+"</EquipID><LoginId/><SerialNo/><SParamList><SParam><ParamName>"+
			"</ParamName><ParamValue></ParamValue></SParam></SParamList></SService></SServiceList></InputParams></Operation></Service>";
		
		logger.info("Request sent to TABS is = "+serviceName);
		
		params.setPServices(serviceName);
		params.setPAdditonalparams("<?xml version=\"1.0\" encoding=\"UTF-8\"?><SParamList></SParamList>");
		
		try {
			responseElement = orderProxy.changeservice(params);
			logger.info("Response from TABS = "+responseElement.getResult());
			String responseCode = xmlUtility.getChangeServiceResponseCode(responseElement.getResult());
			
			if ((responseCode != null && responseCode.equalsIgnoreCase("0")) || 
					(responseCode != null && responseCode.equalsIgnoreCase("3172")))
			{
				transactionlog = new TransactionLog();
				transactionlog.setDate_created(new GregorianCalendar());
				transactionlog.setMsisdn(subscriberDetail.getMsisdn());
				transactionlog.setDescription("Change TABS Service");
				transactionlog.setService(receiverParams[1]);
				transactionlog.setStatus("Completed");
				
				hibernateUtility.saveTransactionlog(transactionlog);
				
				logger.info("ChangeSubscriberTABSServiceCommandImpl for subscriber "+subscriberDetail.getMsisdn()+" returned with code "+responseCode);
				
				return StatusCodes.SUCCESS;
			}
			else return StatusCodes.OTHER_ERRORS_CHANGE_SERVICE;
			
		} catch (RemoteException e) {
			e.printStackTrace();
			return StatusCodes.OTHER_ERRORS_CHANGE_SERVICE;
		}
	}

	public int logTransaction()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	public void setReceiverParameters(String receiverParams)
	{
		this.receiverParam = receiverParams;
	}
	
	private String stripLeadingMsisdnPrefix(String msisdn){
		String Msisdn = msisdn;
		if (msisdn.startsWith("0")){
			return Msisdn.substring(1, Msisdn.length());
		}
		else if (Msisdn.startsWith("234")){
			return Msisdn.substring(3, Msisdn.length());
		}
		else if(Msisdn.startsWith("+234")){
			return Msisdn.substring(4, Msisdn.length());
		}
		else return Msisdn;
	}

}
