package com.vasconsulting.www.interfaces.impl;

import java.util.GregorianCalendar;
import java.util.Map;

import org.apache.log4j.Logger;

import com.celtel.databundle.service.impl.UCIPServiceRequestManager;
import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.domain.TransactionLog;
import com.vasconsulting.www.interfaces.Command;
import com.vasconsulting.www.interfaces.HibernateUtility;
import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.utility.BillingPlanObjectUtility;
import com.vasconsulting.www.utility.HibernateUtilityImpl;
import com.vasconsulting.www.utility.StatusCodes;

public class SetDedicatedAccountCommandImpl implements Command {
	private UCIPServiceRequestManager ucipConnector = new UCIPServiceRequestManager();
	private String receiverParams;
	private SubscriberDetail subscriberDetail;
	private HibernateUtility hibernateUtility;
	Map<String, String> ucipReturns;
	private BillingPlanObjectUtility billingPlanObject;
	private TransactionLog transactionLog;
	Logger logger = Logger.getLogger(SetDedicatedAccountCommandImpl.class);
	
	
	@SuppressWarnings("unchecked")
	public int execute() {
		/**
		 * Retrieve the spring managed beans from the container.
		 */
		subscriberDetail = 
			(SubscriberDetail)ContextLoaderImpl.getBeans("subscriberDetail");
		
		hibernateUtility = 
			(HibernateUtility)ContextLoaderImpl.getBeans("hibernateUtility");
		
		billingPlanObject = 
			(BillingPlanObjectUtility)ContextLoaderImpl.getBeans("billingPlanObject");
		
		logger.info("Execute has been called on SetDedicatedAccountCommandImpl for subscriber subscriber with msisdn "+subscriberDetail.getMsisdn());
		
		String [] receiverParamsValues = receiverParams.split(",");
		String [] daValueToSet = receiverParamsValues[0].split(":");
		
		if (receiverParamsValues != null && receiverParamsValues.length > 1)
		{
			try {
				ucipReturns = ucipConnector.updateSubscriberDedicatedAccount(subscriberDetail.getMsisdn(), 
						daValueToSet[1], daValueToSet[0] ,
						 billingPlanObject.getExternalData());
				
				logger.info("Response from AIR is "+ucipReturns);
				
				if (ucipReturns.get("responseCode").equalsIgnoreCase("0")){
					transactionLog = new TransactionLog();
				
					transactionLog.setDate_created(new GregorianCalendar());
					transactionLog.setDescription("Dedicated Account SETUP");
					transactionLog.setMsisdn(subscriberDetail.getMsisdn());
					transactionLog.setService("Added value is"+daValueToSet[1]);
					transactionLog.setShortcode(billingPlanObject.getShortCode());
					transactionLog.setStatus("Completed");
					
					hibernateUtility.saveTransactionlog(transactionLog);
				}
				else {
					return new Integer(ucipReturns.get("responseCode")).intValue();
				}
				
			} catch (NumberFormatException e) {
				e.printStackTrace();
				return StatusCodes.WRONG_DAVALUE_FORMAT;
			} catch (Exception e) {
				e.printStackTrace();
				return StatusCodes.OTHER_ERRORS_IN;
			}
			return StatusCodes.SUCCESS;
		}
		else
		{
			return StatusCodes.WRONG_DAVALUE_FORMAT;
		}
	}
	public int logTransaction()
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	public void setReceiverParameters(String receiverParams)
	{
		this.receiverParams = receiverParams;
	}

}
