package com.vasconsulting.www.interfaces.impl;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;

import org.apache.log4j.Logger;

import ws.its.tabs.webservices.TBI_KPI_PKG.TBI_KPI_PKG_wsdl.TBI_KPI_PKGProxy;
import ws.its.tabs.webservices.TBI_KPI_PKG.TBI_KPI_PKG_wsdl.types.GetSubscriberInformationElement;
import ws.its.tabs.webservices.TBI_KPI_PKG.TBI_KPI_PKG_wsdl.types.GetSubscriberInformationResponseElement;

import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.interfaces.HibernateUtility;
import com.vasconsulting.www.interfaces.RenewalCommand;
import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.utility.RIMQueryUtil;
import com.vasconsulting.www.utility.StatusCodes;
import com.vasconsulting.www.utility.XMLUtility;

public class AutoRenewSubscriberDBAndRIMCommandImpl implements RenewalCommand
{
	//@SuppressWarnings("unused")
	private String receiverParams;
	private SubscriberDetail subscriberDetail;
	private HibernateUtility hibernateUtility = (HibernateUtility)ContextLoaderImpl.getBeans("hibernateUtility");
	Logger logger = Logger.getLogger(AutoRenewSubscriberDBAndRIMCommandImpl.class);
	private int actionResponse;
	private XMLUtility xmlUtility = (XMLUtility)ContextLoaderImpl.getBeans("xmlUtility");
	private TBI_KPI_PKGProxy tbiProxy = new TBI_KPI_PKGProxy();
	private RIMQueryUtil rimUtility = (RIMQueryUtil)ContextLoaderImpl.getBeans("rimUtility");
	private int rimStatus;
	
	/**
	 * This method is used to get the last day of the month.
	 * @param noOfDays
	 * @return
	 */
	private GregorianCalendar getLastDateOfMonth(){
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int month = Calendar.getInstance().get(Calendar.MONTH);
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.set(year, month, day);		
		return calendar;
	}
	
	private boolean isFirstDayOfMonth()
	{
		int dayOfMonth = new GregorianCalendar().get(GregorianCalendar.DAY_OF_MONTH);
		
		if (dayOfMonth == 1) return true;
		else return false;
	}
	
	public int execute()
	{
		logger.info("Execute called on AutoRenewSubscriberCommandImpl for subscriber with MSISDN = "+subscriberDetail.getMsisdn());
		
		if (isFirstDayOfMonth())
		{
			String currentStatus = subscriberDetail.getStatus();
			
			GetSubscriberInformationElement subParams = new GetSubscriberInformationElement();
			subParams.setSubno(stripLeadingMsisdnPrefix(subscriberDetail.getMsisdn()));
			
			try {
				GetSubscriberInformationResponseElement responseElement = tbiProxy.getSubscriberInformation(subParams);
				
				HashMap<String, String> tabsResponse = xmlUtility.processTABSResponse(responseElement.getResult());
				
				logger.info("Call to check Subscriber Status on TABS API returned result : "+tabsResponse);
				
				if (tabsResponse.get("errorResponse") != null) actionResponse =  StatusCodes.OTHER_ERRORS;
				else if(tabsResponse.get("STATUS").equalsIgnoreCase("30")) 
				{
					actionResponse =  StatusCodes.SUCCESS;
				}
				else
				{
					actionResponse = StatusCodes.BARRED_SUBSCRIBER;
				}
				
			} catch (RemoteException e) {
				e.printStackTrace();
				actionResponse = StatusCodes.OTHER_ERRORS;
			}
			
			if (actionResponse == StatusCodes.OTHER_ERRORS)
			{
				//Send email to administrator about this failure and continue to other subscribers.
				//set actionResponse to 0
				continue;
			}
			else if ((currentStatus.trim().equalsIgnoreCase("Active") && actionResponse ==  StatusCodes.SUCCESS) || 
					(currentStatus.trim().equalsIgnoreCase("Deactivated") && actionResponse ==  StatusCodes.SUCCESS))
			{
				rimStatus = rimUtility.activateSingleServiceSubscription(subscriberDetail);
				
				if (rimStatus == 0 || (rimStatus >= 21000 && rimStatus <= 25000)) 
				{
					subscriberDetail.setNext_subscription_date(getLastDateOfMonth());	
					subscriberDetail.setStatus("Active");
					rimStatus = hibernateUtility.updateSubscriberDetail(subscriberDetail);
					
					if (rimStatus != StatusCodes.SUCCESS)
						//send an email to admin
						
					actionResponse = 0;
				}
				else
				{
					//log this error
					//send email to admin about this failure
					actionResponse = 0;
				}
			}
			else if (currentStatus.trim().equalsIgnoreCase("Active") && actionResponse ==  StatusCodes.BARRED_SUBSCRIBER)
			{
				rimStatus = rimUtility.cancelSubscription(subscriberDetail);
				
				if (rimStatus == 0 || (rimStatus >= 21000 && rimStatus <= 25000))
				{
					subscriberDetail.setStatus("Deactivated");		
					actionResponse = hibernateUtility.updateSubscriberDetail(subscriberDetail);
					
					if (rimStatus != StatusCodes.SUCCESS)
						//send an email to admin about this failure
						
					actionResponse = 0;
				}
				else
				{
					//log this error
					//send email to admin about this failure
					actionResponse = 0;
				}
			}
			
			logger.info("The call to renew all subscribers RIM and DB records" +
					"at the begining of the month ran for subscriber "+subscriberDetail.getMsisdn()+" and" +
					" returned a response of "+actionResponse);
			return actionResponse;
		}
		else return -100;
	}

	public void setReceiverParameters(String receiverParams)
	{
		this.receiverParams = receiverParams;
	}

	public int logTransaction()
	{
		return 0;
	}

	public void setSubscriber(SubscriberDetail subscriber)
	{
		this.subscriberDetail = subscriber;
	}
	
	private String stripLeadingMsisdnPrefix(String msisdn){
		String Msisdn = msisdn;
		if (msisdn.startsWith("0")){
			return Msisdn.substring(1, Msisdn.length());
		}
		else if (Msisdn.startsWith("234")){
			return Msisdn.substring(3, Msisdn.length());
		}
		else if(Msisdn.startsWith("+234")){
			return Msisdn.substring(4, Msisdn.length());
		}
		else return Msisdn;
	}

}
