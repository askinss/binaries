package com.vasconsulting.www.interfaces.impl;

import java.text.DecimalFormat;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.Map;

import org.apache.log4j.Logger;

import com.celtel.databundle.service.impl.UCIPServiceRequestManager;
import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.domain.TransactionLog;
import com.vasconsulting.www.interfaces.Command;
import com.vasconsulting.www.interfaces.HibernateUtility;
import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.utility.BillingPlanObjectUtility;
import com.vasconsulting.www.utility.StatusCodes;

public class DeductPrepServiceFeeCommandImpl implements Command {
	private UCIPServiceRequestManager ucipConnector = new UCIPServiceRequestManager();
	private SubscriberDetail subscriberDetail;
	private BillingPlanObjectUtility billingPlanObjectLive;
	private TransactionLog transactionLog;
	private HibernateUtility hibernateUtility;
	private String receiverParams;
	private Logger logger = Logger.getLogger(DeductPrepServiceFeeCommandImpl.class);
	
	public int execute() {
		/**
		 * Retrieve the Spring managed beans from the container
		 */
		
		subscriberDetail = 
			(SubscriberDetail)ContextLoaderImpl.getBeans("subscriberDetail");
		billingPlanObjectLive = 
			(BillingPlanObjectUtility)ContextLoaderImpl.getBeans("billingPlanObject");
		hibernateUtility = 
			(HibernateUtility)ContextLoaderImpl.getBeans("hibernateUtility");
		
		try {
			if (receiverParams == null)
				return StatusCodes.ERROR_NO_AMT_TO_DEDUCT;
			
			int amountToDeduct = new Integer(receiverParams).intValue();			
			
			amountToDeduct = amountToDeduct * -100;
			
			logger.info("The actual amount to deduct from subscriber ["+subscriberDetail.getMsisdn()+"] is = "+amountToDeduct);			
						
			@SuppressWarnings("unchecked")
			Map<String, String> ucipResponse = ucipConnector.updateSubscriberBalance(subscriberDetail.getMsisdn(), 
					new Integer(amountToDeduct).toString(), billingPlanObjectLive.getExternalData());
			
			transactionLog = new TransactionLog();
			transactionLog.setDate_created(new GregorianCalendar());		
			transactionLog.setMsisdn(subscriberDetail.getMsisdn());
			transactionLog.setService(subscriberDetail.getServiceplan());
			transactionLog.setShortcode(billingPlanObjectLive.getShortCode());			
			transactionLog.setDescription("DEDUCT AIRTIME");
			
			if (ucipResponse.get("responseCode").equalsIgnoreCase("0")) {
				transactionLog.setStatus("SUCCESSFUL");
				hibernateUtility.saveTransactionlog(transactionLog);
				
				return StatusCodes.SUCCESS;
			}
			else {
				transactionLog.setStatus("FAILED");
				hibernateUtility.saveTransactionlog(transactionLog);
				
				return StatusCodes.INSUFFICENT_BALANCE;
			}
			
		} catch (Exception e) {			
			e.printStackTrace();
			return StatusCodes.OTHER_ERRORS_IN_DEDUCTION;
		}
	}
	
	public int logTransaction()
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	public void setReceiverParameters(String receiverParams)
	{
		this.receiverParams = receiverParams;
	}
	
	private int daysBetween(GregorianCalendar startDate, GregorianCalendar endDate) {  
		GregorianCalendar date = (GregorianCalendar) startDate.clone();  
		int daysBetween = 0;  
		while (date.before(endDate)) {  
			date.add(GregorianCalendar.DAY_OF_MONTH, 1);  
			daysBetween++;  
		}  
		return daysBetween;  
	}
	
	private GregorianCalendar getLastDateOfMonth(){
		GregorianCalendar calendar  = new GregorianCalendar();
		int dayOfMonth  = calendar.getActualMaximum(GregorianCalendar.DAY_OF_MONTH);
		
		int daysToAdd = dayOfMonth - calendar.get(GregorianCalendar.DAY_OF_MONTH);
		
		calendar.add(GregorianCalendar.DAY_OF_MONTH, daysToAdd);	
		return calendar;
	}

}
