package com.vasconsulting.www.interfaces.impl;

import java.util.GregorianCalendar;

import org.apache.log4j.Logger;

import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.domain.TransactionLog;
import com.vasconsulting.www.interfaces.Command;
import com.vasconsulting.www.interfaces.HibernateUtility;
import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.utility.BillingPlanObjectUtility;
import com.vasconsulting.www.utility.RIMQueryUtil;
import com.vasconsulting.www.utility.StatusCodes;

public class CreateBlackberryServiceCommandImpl implements Command {
	private RIMQueryUtil rimUtility = new RIMQueryUtil();
	private HibernateUtility hibernateUtility;
	private SubscriberDetail subscriberDetail;
	private int rimStatus;
	private String receiverParams;
	private BillingPlanObjectUtility billingPlanObject;
	Logger logger = Logger.getLogger(CreateBlackberryServiceCommandImpl.class);
	
	private TransactionLog transactionLog;
		
	public int execute() {
		/**
		 * Retrieve the spring managed beans from the container.
		 */
		subscriberDetail = 
			(SubscriberDetail)ContextLoaderImpl.getBeans("subscriberDetail");		
		hibernateUtility = 
			(HibernateUtility)ContextLoaderImpl.getBeans("hibernateUtility");
		billingPlanObject = 
			(BillingPlanObjectUtility)ContextLoaderImpl.getBeans("billingPlanObject");
		
		logger.info("Execute called on CreateBlackberryServiceCommandImpl for subscriber with msisdn "+subscriberDetail.getMsisdn());
		logger.info("Activating RIM services "+receiverParams+", for subscriber = "+subscriberDetail.getMsisdn());
		
		String[] rimParams = this.receiverParams.split(",");
		
		if (rimParams.length <= 0)
			return StatusCodes.WRONG_SERVICENAME_FORMAT;
					
		subscriberDetail.setServiceplan(rimParams[0]);
		
		rimStatus = rimUtility.activateSubscriptionByUSSDChannel(subscriberDetail, rimParams );
		
		transactionLog = new TransactionLog();
		transactionLog.setDate_created(new GregorianCalendar());
		transactionLog.setDescription("RIM ACTIVATION");
		transactionLog.setMsisdn(subscriberDetail.getMsisdn());
		transactionLog.setService(rimParams[0]);
				
		if (rimStatus == 0 || (rimStatus >= 21000 && rimStatus <= 21000)) 
		{
			logger.info("RIM Call returned a value of "+rimStatus+". Result ok, proceeding.");
			transactionLog.setStatus("SUCCESSFUL");
			transactionLog.setShortcode(billingPlanObject.getShortCode());
			rimStatus = 0;
		}
		else 
		{
			transactionLog.setStatus("FAILED");
			transactionLog.setShortcode(billingPlanObject.getShortCode());
		}
		
		hibernateUtility.saveTransactionlog(transactionLog);
		
		return rimStatus;
	}

	public int logTransaction()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	public void setReceiverParameters(String receiverParams)
	{
		this.receiverParams = receiverParams;
		
	}

}
