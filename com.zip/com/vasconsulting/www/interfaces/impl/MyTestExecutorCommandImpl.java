package com.vasconsulting.www.interfaces.impl;

import org.apache.log4j.Logger;

import com.vasconsulting.www.interfaces.Command;
import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.utility.EmailTaskExecutor;

public class MyTestExecutorCommandImpl implements Command
{
	Logger logger = Logger.getLogger(MyTestExecutorCommandImpl.class);
	public int execute()
	{
		EmailTaskExecutor emailExecutor = (EmailTaskExecutor)ContextLoaderImpl.getBeans("myEmailTaskExecutor");
		emailExecutor.sendQueuedEmails("This is a test e-mail from the all new Service Delivery Platform for Airtel Nigeria.");

		return 0;
	}

	public void setReceiverParameters(String receiverParams)
	{
		// TODO Auto-generated method stub

	}

	public int logTransaction()
	{
		// TODO Auto-generated method stub
		return 0;
	}

}
