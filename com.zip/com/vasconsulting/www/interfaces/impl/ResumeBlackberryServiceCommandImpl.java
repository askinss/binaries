package com.vasconsulting.www.interfaces.impl;

import com.vasconsulting.www.interfaces.Command;
import com.vasconsulting.www.utility.RIMQueryUtil;

public class ResumeBlackberryServiceCommandImpl implements Command {
	private RIMQueryUtil rimUtility;
	
	public ResumeBlackberryServiceCommandImpl(RIMQueryUtil rimUtility){
		this.rimUtility = rimUtility;
	}
	
	public int execute() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int logTransaction()
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	public void setReceiverParameters(String receiverParams)
	{
		// TODO Auto-generated method stub
		
	}
}
