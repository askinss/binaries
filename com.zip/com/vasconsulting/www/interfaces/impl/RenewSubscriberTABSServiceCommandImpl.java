package com.vasconsulting.www.interfaces.impl;

import java.rmi.RemoteException;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;

import ws.its.tabs.webservices.ordermangement.OrderManagement_wsdl.OrderManagementProxy;
import ws.its.tabs.webservices.ordermangement.OrderManagement_wsdl.types.ChangeserviceElement;
import ws.its.tabs.webservices.ordermangement.OrderManagement_wsdl.types.ChangeserviceResponseElement;

import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.domain.TransactionLog;
import com.vasconsulting.www.interfaces.HibernateUtility;
import com.vasconsulting.www.interfaces.RenewalCommand;
import com.vasconsulting.www.utility.HibernateUtilityImpl;
import com.vasconsulting.www.utility.LoadAllProperties;
import com.vasconsulting.www.utility.StatusCodes;
import com.vasconsulting.www.utility.XMLUtility;

public class RenewSubscriberTABSServiceCommandImpl implements RenewalCommand
{
	private SubscriberDetail subscriberDetail;
	private String receiverParams;
	Logger logger = Logger.getLogger(RenewSubscriberTABSServiceCommandImpl.class);
	private HibernateUtility hibernateUtility = new HibernateUtilityImpl();
	private LoadAllProperties properties = new LoadAllProperties();
	private TransactionLog transactionlog = new TransactionLog();
	XMLUtility xmlUtility = new XMLUtility();
	private OrderManagementProxy orderProxy = new OrderManagementProxy();
	private ChangeserviceResponseElement responseElement;
	
	public int execute()
	{
		logger.info("Execute called on RenewSubscriberTABSServiceCommandImpl for subscriber with MSISDN = "+subscriberDetail.getMsisdn());
		String[] receiverParamValues = receiverParams.split(",");
		
		if (receiverParamValues.length != 2) return StatusCodes.WRONG_SERVICEVALUE_FORMAT;
		
		ChangeserviceElement params = new ChangeserviceElement();
		params.setPSubno(subscriberDetail.getMsisdn());
		params.setPUsername(properties.getProperty("tabschangeserviceusername"));//dynamic from props file
		params.setPSubscrtype("G");
		params.setPArea("0");
		params.setPSubsidyFlag("N");
		params.setPSndcmd("Y");
		
		String serviceName = "<Service name=\"OrderManagement\" msgType=\"Input\"><Operation name=\"op1\" paramName=\"service\">"+
			"<InputParams><SServiceList><SService><Action>"+receiverParamValues[0]+"</Action><EquipID>"+receiverParamValues[1]+
			"</EquipID><LoginId/><SerialNo/><SParamList><SParam><ParamName>"+
			"</ParamName><ParamValue></ParamValue></SParam></SParamList></SService></SServiceList></InputParams></Operation></Service>";
		
		params.setPServices(serviceName);
		params.setPAdditonalparams("<?xml version=\"1.0\" encoding=\"UTF-8\"?><SParamList></SParamList>");
		
		try {
			responseElement = orderProxy.changeservice(params);
			
			String responseCode = xmlUtility.getChangeServiceResponseCode(responseElement.getResult());
			
			if ((responseCode != null && responseCode.equalsIgnoreCase("0")) || 
					(responseCode != null && responseCode.equalsIgnoreCase("3172")))
			{
				transactionlog.setDate_created(new GregorianCalendar());
				transactionlog.setMsisdn(subscriberDetail.getMsisdn());
				transactionlog.setDescription("Renew TABS Service: By Renewal Module");
				transactionlog.setService(receiverParamValues[1]);
				transactionlog.setStatus("Completed");
				
				hibernateUtility.saveTransactionlog(transactionlog);
				
				logger.info("RenewSubscriberTABSServiceCommandImpl for subscriber "+subscriberDetail.getMsisdn()+" returned with code"+responseCode);
				
				return StatusCodes.SUCCESS;
			}
			else return StatusCodes.OTHER_ERRORS_CHANGE_SERVICE;
			
		} catch (RemoteException e) {
			e.printStackTrace();
			return StatusCodes.OTHER_ERRORS_CHANGE_SERVICE;
		}
		
	}

	public void setReceiverParameters(String receiverParams)
	{
		this.receiverParams = receiverParams;
	}

	public int logTransaction()
	{
		return 0;
	}

	public void setSubscriber(SubscriberDetail subscriber)
	{
		this.subscriberDetail = subscriber;
	}

}
