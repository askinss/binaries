package com.vasconsulting.www.interfaces.impl;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import ws.its.tabs.webservices.TBI_KPI_PKG.TBI_KPI_PKG_wsdl.TBI_KPI_PKGProxy;
import ws.its.tabs.webservices.TBI_KPI_PKG.TBI_KPI_PKG_wsdl.types.GetSubscriberInformationElement;
import ws.its.tabs.webservices.TBI_KPI_PKG.TBI_KPI_PKG_wsdl.types.GetSubscriberInformationResponseElement;
import ws.its.tabs.webservices.ordermangement.OrderManagement_wsdl.OrderManagementProxy;
import ws.its.tabs.webservices.ordermangement.OrderManagement_wsdl.types.ChangeserviceElement;
import ws.its.tabs.webservices.ordermangement.OrderManagement_wsdl.types.ChangeserviceResponseElement;

import com.celtel.databundle.service.impl.UCIPServiceRequestManager;
import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.domain.TransactionLog;
import com.vasconsulting.www.interfaces.HibernateUtility;
import com.vasconsulting.www.interfaces.RenewalCommand;
import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.utility.EmailTaskExecutor;
import com.vasconsulting.www.utility.LoadAllProperties;
import com.vasconsulting.www.utility.RIMQueryUtil;
import com.vasconsulting.www.utility.StatusCodes;
import com.vasconsulting.www.utility.XMLUtility;

public class RenewSubscriberOnBBPostCommandImpl implements RenewalCommand
{
	private String receiverParams;
	private SubscriberDetail subscriberDetail;
	private UCIPServiceRequestManager ucipConnector = new UCIPServiceRequestManager();
	private HibernateUtility hibernateUtility = (HibernateUtility)ContextLoaderImpl.getBeans("hibernateUtility");
	EmailTaskExecutor emailExecutor = (EmailTaskExecutor)ContextLoaderImpl.getBeans("myEmailTaskExecutor");
	Logger logger = Logger.getLogger(RenewSubscriberOnBBPostCommandImpl.class);
	private int actionResponse;
	private XMLUtility xmlUtility = new XMLUtility();
	private TBI_KPI_PKGProxy tbiProxy = new TBI_KPI_PKGProxy();
	private ChangeserviceResponseElement responseElement;
	private RIMQueryUtil rimUtility = new RIMQueryUtil();
	private int rimStatus;
	private String[] receiverParamsValue;
	private Map<String, String> ucipReturns= new HashMap<String, String>();
	private String errorMessage = "";
	private LoadAllProperties properties = (LoadAllProperties)ContextLoaderImpl.getBeans("loadProperties");
	
	/**
	 * This method is used to get the last day of the month.
	 * @param noOfDays
	 * @return
	 */
	private GregorianCalendar getLastDateOfMonth(){
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int month = Calendar.getInstance().get(Calendar.MONTH);
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.set(year, month, day);		
		return calendar;
	}
	
	@SuppressWarnings("unchecked")
	public int execute()
	{
		logger.info("Execute called on RenewSubscriberOnBBPostCommandImpl for subscriber with MSISDN = "+subscriberDetail.getMsisdn());
		
		String currentStatus = subscriberDetail.getStatus();
		String servicePlanName = subscriberDetail.getServiceplan();
		
		GetSubscriberInformationElement subParams = new GetSubscriberInformationElement();
		subParams.setSubno(stripLeadingMsisdnPrefix(subscriberDetail.getMsisdn()));		
		
		try 
		{
			GetSubscriberInformationResponseElement responseElement = tbiProxy.getSubscriberInformation(subParams);
			
			HashMap<String, String> tabsResponse = xmlUtility.processTABSResponse(responseElement.getResult());
			
			logger.info("Call to check Subscriber Status on TABS API returned result : "+tabsResponse);
			
			if (tabsResponse.get("errorResponse") != null) actionResponse =  StatusCodes.OTHER_ERRORS;
			else if(tabsResponse.get("STATUS").equalsIgnoreCase("30")) 
			{
				subscriberDetail.setStatus("Active");
				actionResponse =  StatusCodes.SUCCESS;
			}
			else
			{
				subscriberDetail.setStatus("Deactivated");
				actionResponse = StatusCodes.BARRED_SUBSCRIBER;
			}
			
		} catch (RemoteException e) {
			e.printStackTrace();
			actionResponse = StatusCodes.OTHER_ERRORS;
		}
		
		if (actionResponse == StatusCodes.OTHER_ERRORS)
		{
			errorMessage = "There was an error conencting to the TABS Interface to pull details for Postpaid Subscriber renewal. " +
					"Please check and confirm its not continious";
			logger.error("Error: Error connecting to TABS");
			emailExecutor.sendQueuedEmails(errorMessage);
			return actionResponse;
		}
		else if (receiverParams.equalsIgnoreCase("") || receiverParams == null)
		{
			errorMessage = "The configuration file for the renewal module is either corrupt or not properly set. Please consult the documentation " +
					"and then set the details for Postpaid Blackberry renewal.";
			logger.error("Error: Error renewal setting for application not set");
			emailExecutor.sendQueuedEmails(errorMessage);
			return StatusCodes.OTHER_ERRORS;
		}
		else if ((currentStatus.trim().equalsIgnoreCase("Active") && actionResponse ==  StatusCodes.SUCCESS) || 
				(currentStatus.trim().equalsIgnoreCase("Deactivated") && actionResponse ==  StatusCodes.SUCCESS))
		{
			logger.info("The value of the receiverParams set = "+receiverParams);
			
			//Prosumer Prepaid:Internet Browsing,Enterprise Plus:Internet Browsing,Prepaid BIS Social,Prepaid BIS Lite,10:10240,5:10000,20
			receiverParamsValue = receiverParams.split(",");
			String [] servicePlans = null;	
			String costOfService = "";
			
			//Loop through the configured param value, pick out the RIM part and build the RIM service names
			for (int count = 0;count < 4 ; count++){
				if (receiverParamsValue[count].contains(servicePlanName.trim()))
				{
					String []serviceNames = receiverParamsValue[count].split(":");
					
					servicePlans = new String[serviceNames.length - 1];
					
					for (int i=0; i < serviceNames.length -1;i++){
						servicePlans[i] = serviceNames[i];
					}
					
					costOfService = serviceNames[serviceNames.length - 1];
				}
			}
			
			if (servicePlans != null)
			{
				rimStatus = rimUtility.activateSubscriptionByUSSDChannel(subscriberDetail, servicePlans);
			}
			else
			{
				errorMessage = "The configuration file for the renewal module is either corrupt or not properly set for the Blackberry service. " +
						"Please consult the documentation " +
				"and then set the details for Postpaid Blackberry renewal.";
				logger.error("Error: Error renewal setting for application not set properly for the Blackberry services");
				emailExecutor.sendQueuedEmails(errorMessage);
				return StatusCodes.OTHER_ERRORS;
			}
			
			for (int count = 4; count <= 5; count++)
			{
				servicePlans = receiverParamsValue[count].split(":");
				
				try {
					ucipReturns = ucipConnector.updateSubscriberDedicatedAccount(subscriberDetail.getMsisdn(), 
							servicePlans[1], servicePlans[0] ,
							 subscriberDetail.getServiceplan().replaceAll(" ", "")+"_RENEWAL");
				} catch (Exception e) {
					errorMessage = "################CRITICAL###############\n" +
					"The subscriber " +subscriberDetail.getMsisdn()+" has not been awarded appropriate DA value. Please reconcile manually";
					emailExecutor.sendQueuedEmails(errorMessage);
					e.printStackTrace();
				}
			}			
			
			try {
				ucipReturns = ucipConnector.updateSubscriberBalance(subscriberDetail.getMsisdn(), 
						costOfService, subscriberDetail.getServiceplan().replaceAll(" ", "")+"_RENEWAL");
			} catch (Exception e) {
				errorMessage = "################CRITICAL###############\n" +
				"The subscriber " +subscriberDetail.getMsisdn()+" has not been charged for this month's service, due to an error. " +
						"Please reconcile manually";
				emailExecutor.sendQueuedEmails(errorMessage);
				e.printStackTrace();
			}
			
			
			if ((rimStatus == 0 || (rimStatus >= 21000 && rimStatus <= 25000)) && 
					(ucipReturns != null && ucipReturns.get("responseCode").equalsIgnoreCase("0"))) 
			{
				subscriberDetail.setNext_subscription_date(getLastDateOfMonth());	
				subscriberDetail.setStatus("Active");
				rimStatus = hibernateUtility.updateSubscriberDetail(subscriberDetail);
				
				if (rimStatus == StatusCodes.SUCCESS)
				{
					TransactionLog transactionLog = new TransactionLog();
					transactionLog.setDate_created(new GregorianCalendar());		
					transactionLog.setMsisdn(subscriberDetail.getMsisdn());
					transactionLog.setService(subscriberDetail.getServiceplan());
					transactionLog.setShortcode("RENEWAL");			
					transactionLog.setDescription("APPLICATION RENEW MODULE");
					transactionLog.setStatus("SUCCESSFUL");
					hibernateUtility.saveTransactionlog(transactionLog);
				}
				else
				{
					errorMessage = "################CRITICAL###############\n" +
							"The subscriber " +subscriberDetail.getMsisdn()+" has been renewed but the record was NOT " +
							"updated on the database. Please rectify manually."+
					"and then set the details for Postpaid Blackberry renewal.";
					logger.error("Error: Error subscriber detail was not updated on the database. Please rectify manually.");
					emailExecutor.sendQueuedEmails(errorMessage);
				}
					
				actionResponse = 0;
			}
			else
			{
				//log this error
				emailExecutor.sendQueuedEmails("");
				actionResponse = 0;
			}
		}
		else if (currentStatus.trim().equalsIgnoreCase("Active") && actionResponse ==  StatusCodes.BARRED_SUBSCRIBER)
		{
			rimStatus = rimUtility.cancelSubscription(subscriberDetail);
			
			if (rimStatus == 0 || (rimStatus >= 21000 && rimStatus <= 25000))
			{
				subscriberDetail.setStatus("Deactivated");		
				actionResponse = hibernateUtility.updateSubscriberDetail(subscriberDetail);
				
				if (rimStatus != StatusCodes.SUCCESS)
				{
					errorMessage = "Subscriber "+subscriberDetail.getMsisdn()+ " has been deactivated successfully on RIM " +
							" because of barred status " +
							"on TABS, but record was not updated successfully in database. Please reconcile manually";
					emailExecutor.sendQueuedEmails(errorMessage);
				}
					
				actionResponse = 0;
			}
			else
			{
				errorMessage = "Subscriber "+subscriberDetail.getMsisdn()+ " could not be deactivated on RIM " +
				" because of application error. Please reconcile manually";
				emailExecutor.sendQueuedEmails(errorMessage);
				actionResponse = 0;
			}
		}
		else if (currentStatus.trim().equalsIgnoreCase("Deactivated") && actionResponse ==  StatusCodes.BARRED_SUBSCRIBER)
		{
			OrderManagementProxy orderProxy = new OrderManagementProxy();
			
			ChangeserviceElement params = new ChangeserviceElement();
			
			String []tabsService = new String[4]; 
			tabsService[0]	= "BIS_PRO";
			tabsService[1]	= "BES_PRO";
			tabsService[2]	= "BBLITE_SOC";
			tabsService[3]	= "BBLITE_MSG";
			
			for (String string : tabsService) {
				params.setPSubno(stripLeadingMsisdnPrefix(subscriberDetail.getMsisdn()));
				params.setPUsername(properties.getProperty("tabschangeserviceusername"));//dynamic from props file
				params.setPSubscrtype("G");
				params.setPArea("0");
				params.setPSubsidyFlag("N");
				params.setPSndcmd("Y");
				
				String serviceName = "<Service name=\"OrderManagement\" msgType=\"Input\"><Operation name=\"op1\" paramName=\"service\">"+
				"<InputParams><SServiceList><SService><Action>D</Action><EquipID>"+string+"</EquipID><LoginId/><SerialNo/><SParamList><SParam><ParamName>"+
				"</ParamName><ParamValue></ParamValue></SParam></SParamList></SService></SServiceList></InputParams></Operation></Service>";
			
				logger.info("Request sent to TABS is = "+serviceName);
				
				params.setPServices(serviceName);
				params.setPAdditonalparams("<?xml version=\"1.0\" encoding=\"UTF-8\"?><SParamList></SParamList>");
				
				try{
					responseElement = orderProxy.changeservice(params);
				}
				catch(Exception ex)
				{
					
				}
			}
			
			TransactionLog transactionlog = new TransactionLog();
			transactionlog.setDate_created(new GregorianCalendar());
			transactionlog.setMsisdn(subscriberDetail.getMsisdn());
			transactionlog.setDescription("Deactivate TABS Service");
			transactionlog.setService("");
			transactionlog.setStatus("Completed");
			
			hibernateUtility.saveTransactionlog(transactionlog);
						
		}
		
		logger.info("The call to renew all subscribers at the begining of the month ran for subscriber "+subscriberDetail.getMsisdn()+" and" +
				" returned a response of "+actionResponse);
		return actionResponse;		
	}

	public void setReceiverParameters(String receiverParams)
	{
		this.receiverParams = receiverParams;
	}

	public int logTransaction()
	{
		return 0;
	}

	public void setSubscriber(SubscriberDetail subscriber)
	{
		this.subscriberDetail = subscriber;
	}
	
	private String stripLeadingMsisdnPrefix(String msisdn){
		String Msisdn = msisdn;
		if (msisdn.startsWith("0")){
			return Msisdn.substring(1, Msisdn.length());
		}
		else if (Msisdn.startsWith("234")){
			return Msisdn.substring(3, Msisdn.length());
		}
		else if(Msisdn.startsWith("+234")){
			return Msisdn.substring(4, Msisdn.length());
		}
		else return Msisdn;
	}

}
