/**
 * This is a supper class for all command classes. It defines an execute method that will
 * allow all command implementation receive receiver implementations and perform specific 
 * task on the receiver objects by calling the execute method.
 * @author Nnamdi Jibunoh
 * Date created 18th july 2011
 * Company VAS Consulting
 */
package com.vasconsulting.www.interfaces;

public interface Command {
	public int execute();
	public void setReceiverParameters(String receiverParams);
	public int logTransaction();
}
