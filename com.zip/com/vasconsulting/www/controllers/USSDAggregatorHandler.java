package com.vasconsulting.www.controllers;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.invokers.CommandFactory;
import com.vasconsulting.www.invokers.CommandInvoker;
import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.utility.BillingPlanObjectUtility;
import com.vasconsulting.www.utility.CommandPropertiesUtility;
import com.vasconsulting.www.utility.LoadAllBillingPlanObjects;
import com.vasconsulting.www.utility.LoadAllProperties;
import com.vasconsulting.www.utility.StatusCodes;
import com.vasconsulting.www.utility.SubscriberUSSDConversation;
import com.vasconsulting.www.utility.XMLUtility;

@Controller
public class USSDAggregatorHandler
{
	
	private LoadAllBillingPlanObjects billingPlanObjects;
	private CommandInvoker commandInvoker;
	private CommandFactory commandFactory;
	private XMLUtility xmlUtility;
	private GregorianCalendar calendar = new GregorianCalendar();
	Logger logger = Logger.getLogger(USSDAggregatorHandler.class);
	
	SubscriberUSSDConversation subscriberInSession = (SubscriberUSSDConversation)ContextLoaderImpl.getBeans("subscriberInSession");
	
	private LoadAllProperties properties;
	
	@Autowired
	public void setProperties(LoadAllProperties properties)
	{
		this.properties = properties;
	}
	@Autowired
	public void setXmlUtility(XMLUtility xmlUtility)
	{
		this.xmlUtility = xmlUtility;
	}

	@Autowired
	public void setCommandFactory(CommandFactory commandFactory)
	{
		this.commandFactory = commandFactory;
	}
		
	@Autowired
	public void setCommandInvoker(CommandInvoker commandInvoker)
	{
		this.commandInvoker = commandInvoker;
	}

	@Autowired
	public void setBillingPlanObjects(LoadAllBillingPlanObjects billingPlanObjects)
	{
		this.billingPlanObjects = billingPlanObjects;
	}
	
	private GregorianCalendar getNextSubscriptionDate(int noOfDays){
		GregorianCalendar calendar1 = new GregorianCalendar();
		calendar1.add(GregorianCalendar.DAY_OF_MONTH, new Integer(noOfDays).intValue());
		return calendar1;
	}
	
	/**
	 * This method is used to get the last day of the month.
	 * @param noOfDays
	 * @return
	 */
	private GregorianCalendar getLastDateOfMonth(){
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int month = Calendar.getInstance().get(Calendar.MONTH);
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.set(year, month, day);		
		return calendar;
	}
	
	
	@RequestMapping(value="/ussdxmlservice", method = RequestMethod.POST)
	@ResponseBody
	public void generateSubscriberUSSDMenu(@RequestBody String request, Writer writer) throws IOException
	{
		HashMap<String , String> ussdRequestMap = xmlUtility.getAtosUSSDXmlAsMap(request);
		//HashMap<String , String> ussdRequestMap = xmlUtility.getHomiscoUSSDXmlAsMap(request);//Homisco
		String msisdn = ussdRequestMap.get("msisdn");
		//String msisdn = ussdRequestMap.get("MOBILE_NUMBER");//Homisco
		String msg = ussdRequestMap.get("msg");
		//String msg = ussdRequestMap.get("USSD_BODY");//Homisco
		String responseFromFileText = "";
			
		logger.debug("New USSD message received to process : "+ussdRequestMap);
		
		if (!subscriberInSession.isMsisdnInContainer(msisdn))
		{
			HashMap<String, ArrayList<String>> responseFromConfFile = 
				xmlUtility.getUSSDMessage(xmlUtility.getUSSDConfigRootTag().get("root"));
			
			Iterator<String> iterator = responseFromConfFile.keySet().iterator();
			if (iterator.hasNext())
				responseFromFileText = iterator.next();
			
			if (!responseFromFileText.equalsIgnoreCase("LEAFNODE"))
			{
				subscriberInSession.saveInContainer(msisdn, responseFromConfFile.get(responseFromFileText));
				logger.info("Total number of subscribers accessing the USSD Menu is = "+subscriberInSession.getCurrentSizeOfContainer());
				writer.write(xmlUtility.generateAtosResponse(responseFromFileText, 2));
				//writer.write(xmlUtility.generateHomiscoResponse(ussdRequestMap.get("SESSION_ID"), responseFromFileText, "REQUEST"));
			}
			else
			{
				//TODO:1000 implement logic to call the ref portion of the xml.
				
				subscriberInSession.removeFromContainer(msisdn);
				//writer.write(xmlUtility.generateHomiscoResponse(ussdRequestMap.get("SESSION_ID"), responseFromFileText, "RESPONSE"));
			}
		}
		else
		{
			ArrayList<String> sessionState = subscriberInSession.getMsisdnFromContainer(msisdn);
			responseFromFileText = sessionState.get((new Integer(msg).intValue()) - 1);
			
			HashMap<String, ArrayList<String>> responseFromConfFile = xmlUtility.getUSSDMessage(responseFromFileText);
			
			if (!responseFromFileText.equalsIgnoreCase("LEAFNODE"))
			{
				subscriberInSession.saveInContainer(msisdn, responseFromConfFile.get(responseFromFileText));
				logger.info("Total number of subscribers accessing the USSD Menu is = "+subscriberInSession.getCurrentSizeOfContainer());
				writer.write(xmlUtility.generateAtosResponse(responseFromFileText, 2));
				//writer.write(xmlUtility.generateHomiscoResponse(ussdRequestMap.get("SESSION_ID"), responseFromFileText, "REQUEST"));
			}
			else
			{
				//TODO:1000 implement logic to call the ref portion of the xml.
				
				subscriberInSession.removeFromContainer(msisdn);
				//writer.write(xmlUtility.generateHomiscoResponse(ussdRequestMap.get("SESSION_ID"), responseFromFileText, "RESPONSE"));
			}
		}
	}
	
	
	@RequestMapping(value="/ussdxmlservice", method = RequestMethod.GET)
	public void provisionSubscriber(@RequestParam("msisdn") String msisdn, @RequestParam("msg") String msg, HttpServletResponse response)
	{
		ArrayList<BillingPlanObjectUtility> billingPlans = billingPlanObjects.getAllBillingPlans();
		
		int provisionStatus = -1;
		
		for (BillingPlanObjectUtility billingPlanObjectUtility : billingPlans) {
			
			if (billingPlanObjectUtility.getShortCode().trim().equalsIgnoreCase(msg.trim()))
			{
				logger.info("Billing Plan match found for shortcode : "+msg+" from subscriber "+msisdn);
				logger.info("=====Setting up the subscriber and the selected plan in Session=====");
				
				BillingPlanObjectUtility billingPlanObjectLive = (BillingPlanObjectUtility)ContextLoaderImpl.getBeans("billingPlanObject");				
				billingPlanObjectLive.setCost(billingPlanObjectUtility.getCost());
				billingPlanObjectLive.setStatus(billingPlanObjectUtility.getStatus());
				billingPlanObjectLive.setDescription(billingPlanObjectUtility.getDescription());
				billingPlanObjectLive.setExternalData(billingPlanObjectUtility.getExternalData());
				billingPlanObjectLive.setShortCode(billingPlanObjectUtility.getShortCode());
				billingPlanObjectLive.setSuccessMessage(billingPlanObjectUtility.getSuccessMessage());
				billingPlanObjectLive.setValidity(billingPlanObjectUtility.getValidity());
				billingPlanObjectLive.setCoomandObjects(billingPlanObjectUtility.getCoomandObjects());
				
				SubscriberDetail subscriberDetail = (SubscriberDetail)ContextLoaderImpl.getBeans("subscriberDetail");
				subscriberDetail.setMsisdn(msisdn);
				subscriberDetail.setLast_subscription_date(calendar);
				subscriberDetail.setDate_created(calendar);
				subscriberDetail.setNext_subscription_date(getLastDateOfMonth());
				
				
				logger.info("======Finalized setup=======");
				
				ArrayList<CommandPropertiesUtility> commandProperties = billingPlanObjectUtility.getCoomandObjects();
				
				for (CommandPropertiesUtility commandProps : commandProperties)
				{
					commandInvoker.addCommand(commandFactory.GetCommandInstance(commandProps.getCommand(), "com.vasconsulting.www.interfaces.impl", 
							commandProps.getParam()));					
				}
				
				provisionStatus = commandInvoker.provision();
				
				logger.info("Provision request result is "+provisionStatus+" for subscriber with MSISDN = "+msisdn);
				
				try
				{
					if (provisionStatus != StatusCodes.SUCCESS)
					{
						response.getWriter().write(properties.getProperty(new Integer(provisionStatus).toString()));
						logger.error("The request to provision "+msisdn+" failed with code "+provisionStatus);
						/**
						 * TODO:
						 * Implement what should be done in case of error/success.
						 */
					}
					else
					{
						response.getWriter().write("<ussd><type>3</type><msg>"+billingPlanObjectUtility.getSuccessMessage()+"</msg></ussd>");
					}
				}
				catch(IOException ex){
					ex.printStackTrace();
				}
			}
		}
	}
}
