package com.vasconsulting.www.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.invokers.CommandFactory;
import com.vasconsulting.www.invokers.CommandInvoker;
import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.utility.BillingPlanObjectUtility;
import com.vasconsulting.www.utility.CommandPropertiesUtility;
import com.vasconsulting.www.utility.LoadAllBillingPlanObjects;
import com.vasconsulting.www.utility.LoadAllProperties;
import com.vasconsulting.www.utility.StatusCodes;

@Controller
public class USSDHandler
{
	
	private LoadAllBillingPlanObjects billingPlanObjects;
	private CommandInvoker commandInvoker;
	private CommandFactory commandFactory;
	private GregorianCalendar calendar = new GregorianCalendar();
	Logger logger = Logger.getLogger(USSDHandler.class);
	
	private LoadAllProperties properties;
	
	@Autowired
	public void setProperties(LoadAllProperties properties)
	{
		this.properties = properties;
	}
	
	@Autowired
	public void setCommandFactory(CommandFactory commandFactory)
	{
		this.commandFactory = commandFactory;
	}
		
	@Autowired
	public void setCommandInvoker(CommandInvoker commandInvoker)
	{
		this.commandInvoker = commandInvoker;
	}

	@Autowired
	public void setBillingPlanObjects(LoadAllBillingPlanObjects billingPlanObjects)
	{
		this.billingPlanObjects = billingPlanObjects;
	}
	
	private GregorianCalendar getNextSubscriptionDate(int noOfDays){
		GregorianCalendar calendar1 = new GregorianCalendar();
		calendar1.add(GregorianCalendar.DAY_OF_MONTH, new Integer(noOfDays).intValue());
		return calendar1;
	}
	
	/**
	 * This method is used to get the last day of the month.
	 * @param noOfDays
	 * @return
	 */
	private GregorianCalendar getLastDateOfMonth(){
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int month = Calendar.getInstance().get(Calendar.MONTH);
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
		
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.set(year, month, day);		
		return calendar;
	}
	
	@RequestMapping(value="/ussdservice", method = RequestMethod.GET)
	public void provisionSubscriber(@RequestParam("msisdn") String msisdn, @RequestParam("msg") String msg, HttpServletResponse response)
	{
		ArrayList<BillingPlanObjectUtility> billingPlans = billingPlanObjects.getAllBillingPlans();
		
		int provisionStatus = -1;
		
		for (BillingPlanObjectUtility billingPlanObjectUtility : billingPlans) {
			
			if (billingPlanObjectUtility.getShortCode().trim().equalsIgnoreCase(msg.trim()))
			{
				logger.info("Billing Plan match found for shortcode : "+msg+" from subscriber "+msisdn);
				logger.info("=====Setting up the subscriber and the selected plan in Session=====");
				
				BillingPlanObjectUtility billingPlanObjectLive = (BillingPlanObjectUtility)ContextLoaderImpl.getBeans("billingPlanObject");				
				billingPlanObjectLive.setCost(billingPlanObjectUtility.getCost());
				billingPlanObjectLive.setStatus(billingPlanObjectUtility.getStatus());
				billingPlanObjectLive.setDescription(billingPlanObjectUtility.getDescription());
				billingPlanObjectLive.setExternalData(billingPlanObjectUtility.getExternalData());
				billingPlanObjectLive.setShortCode(billingPlanObjectUtility.getShortCode());
				billingPlanObjectLive.setSuccessMessage(billingPlanObjectUtility.getSuccessMessage());
				billingPlanObjectLive.setValidity(billingPlanObjectUtility.getValidity());
				billingPlanObjectLive.setCoomandObjects(billingPlanObjectUtility.getCoomandObjects());
				
				SubscriberDetail subscriberDetail = (SubscriberDetail)ContextLoaderImpl.getBeans("subscriberDetail");
				subscriberDetail.setMsisdn(msisdn);
				subscriberDetail.setLast_subscription_date(calendar);
				subscriberDetail.setDate_created(calendar);
				subscriberDetail.setNext_subscription_date(getLastDateOfMonth());
				
				
				logger.info("======Finalized setup=======");
				
				ArrayList<CommandPropertiesUtility> commandProperties = billingPlanObjectUtility.getCoomandObjects();
				
				for (CommandPropertiesUtility commandProps : commandProperties)
				{
					commandInvoker.addCommand(commandFactory.GetCommandInstance(commandProps.getCommand(), "com.vasconsulting.www.interfaces.impl", 
							commandProps.getParam()));					
				}
				
				provisionStatus = commandInvoker.provision();
				
				logger.info("Provision request result is "+provisionStatus+" for subscriber with MSISDN = "+msisdn);
				
				try
				{
					if (provisionStatus != StatusCodes.SUCCESS)
					{
						response.getWriter().write(properties.getProperty(new Integer(provisionStatus).toString()));
						logger.error("The request to provision "+msisdn+" failed with code "+provisionStatus);
						/**
						 * TODO:
						 * Implement what should be done in case of error/success.
						 */
					}
					else
					{
						response.getWriter().write("<ussd><type>3</type><msg>"+billingPlanObjectUtility.getSuccessMessage()+"</msg></ussd>");
					}
				}
				catch(IOException ex){
					ex.printStackTrace();
				}
			}
		}
	}
}
