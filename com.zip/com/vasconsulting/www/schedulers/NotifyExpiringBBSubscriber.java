/**
 * This class is an auto renewal class that runs every first day of the month and 
 * automatically renews every subscriber on the Post paid BB plan on the local database
 * and on TABS
 * @author nnamdi Jibunoh
 * @Date 12-8-2011
 */
package com.vasconsulting.www.schedulers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.vasconsulting.www.invokers.ContextLoaderImpl;
import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.interfaces.HibernateUtility;
import com.vasconsulting.www.invokers.CommandFactory;
import com.vasconsulting.www.invokers.CommandInvoker;
import com.vasconsulting.www.utility.BillingPlanObjectUtility;
import com.vasconsulting.www.utility.CommandPropertiesUtility;
import com.vasconsulting.www.utility.HibernateUtilityImpl;
import com.vasconsulting.www.utility.LoadAllBillingPlanObjects;
import com.vasconsulting.www.utility.LoadAllProperties;
import com.vasconsulting.www.utility.SendSmsToKannelService;

public class NotifyExpiringBBSubscriber extends QuartzJobBean
{
	private HibernateUtility hibernateUtility = (HibernateUtility)ContextLoaderImpl.getBeans("hibernateUtility");
	private Logger logger = Logger.getLogger(NotifyExpiringBBSubscriber.class);
	private LoadAllBillingPlanObjects billingPlanObjects = (LoadAllBillingPlanObjects)ContextLoaderImpl.getBeans("loadAllBillingPlanObjects");
	
	
	private LoadAllProperties properties = (LoadAllProperties)ContextLoaderImpl.getBeans("loadProperties");
	private SendSmsToKannelService smsService = (SendSmsToKannelService)ContextLoaderImpl.getBeans("smsService");
	
	private int notificationDay = 0;
	
	
	@Override
	protected void executeInternal(JobExecutionContext arg0)
			throws JobExecutionException
	{
		//Load the notification days from configuration file
		String notificationDays[] = properties.getProperty("daystosendoutsmsnotifications").split(",");
		ArrayList<SubscriberDetail> affectedSubscribers = new ArrayList<SubscriberDetail>();
		
		String notificationMessage = properties.getProperty("renewalnotificationmessage");
		
		ArrayList<BillingPlanObjectUtility> billingPlans = billingPlanObjects.getAllBillingPlans();	
		
		for (Iterator iterator = billingPlans.iterator(); iterator.hasNext();) {
			BillingPlanObjectUtility billingPlanObjectUtility = (BillingPlanObjectUtility) iterator
					.next();
			logger.info("The value of all billingplans are "+billingPlanObjectUtility.getShortCode());
		}
		
		for(String daysToNotify : notificationDays){
			notificationDay = new Integer(daysToNotify).intValue();
			String messageToBeSent;
			
			affectedSubscribers = hibernateUtility.getSubscribersExpiringSoon(notificationDay);
			logger.info("The value of affected SUbscribers = "+affectedSubscribers);
			if (!affectedSubscribers.isEmpty())
			{
				logger.info("Available Subscriber details to process available");
				for(SubscriberDetail subscriberDetail : affectedSubscribers){
					for (BillingPlanObjectUtility plans : billingPlans)
					{
						
						messageToBeSent = String.format(notificationMessage, 
								convertServiceToDisplayValue(subscriberDetail.getServiceplan()), notificationDay, 
								plans.getCost(), subscriberDetail.getNext_subscription_date());
						
						logger.info("Notifiying "+subscriberDetail.getMsisdn()+" of BB renewal with this message "+messageToBeSent);
						
						smsService.sendMessageToKannel(messageToBeSent, subscriberDetail.getMsisdn());
					
					}
				}	
			}else logger.info("There is no data to process for "+daysToNotify+" days");											
		}			
	
	}	
	
	private String convertServiceToDisplayValue(String serviceType){
		if (serviceType.trim().equalsIgnoreCase("Prepaid BIS Lite")) return "Messaging";
		else if (serviceType.trim().equalsIgnoreCase("Prepaid BIS Social")) return "Social";
		else return "";
		
	}
}
