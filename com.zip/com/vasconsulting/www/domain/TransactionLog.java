package com.vasconsulting.www.domain;

import java.util.Calendar;

import com.vasconsulting.www.utility.MD5;

public class TransactionLog {
	private String id;
	private String msisdn;
	private String description;
	private String shortcode;
	private String service;
	private String status;
	
	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	private Calendar date_created;	
	
	
	public String getShortcode() {
		return shortcode;
	}

	public void setShortcode(String shortcode) {
		this.shortcode = shortcode;
	}

	public TransactionLog(){}

	public Calendar getDate_created() {
		return date_created;
	}

	public void setDate_created(Calendar date_created) {
		this.date_created = date_created;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getId() {
		return (this.id == null || this.id.equalsIgnoreCase(""))? 
				MD5.getDigest(System.currentTimeMillis()+""):this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	};
	
		
}
