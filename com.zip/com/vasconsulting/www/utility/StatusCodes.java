package com.vasconsulting.www.utility;

public class StatusCodes
{	
	public final static int SUCCESS = 0;
	public final static int PREPAID_SUBSCRIBER = 500;
	public final static int POSTPAID_SUBSCRIBER = 501;
	
	//General Errors
	public final static int INVALID_MESSAGE = 1000;
	public final static int OTHER_ERRORS = 1010;
	public final static int WRONG_STATUS_FORMAT = 1011;
	public final static int IMSI_AND_MSISDN_CANNOT_BE_EMPTY = 1012;
	public final static int SUBCRIBER_IS_NOT_ON_LEGAL_STATE = 1013;
	public final static int SUBCRIBER_IS_ALREADY_IN_ACTIVE_STATE = 1014;
	public final static int NO_SUBSCRIBER_FOUND_WITH_DETAILS= 1015;
	public final static int SUBSCRIBER_CANNOT_MIGRATE_WHILE_ACTIVE= 1016;
	
	//TABS Error Range
	public final static int BARRED_SUBSCRIBER = 1020;
	public final static int IMSI_NOT_FOUND = 1030;
	public final static int INSUFFICENT_BALANCE = 1040;
	public final static int OTHER_ERRORS_IMSI = 1050;
	public final static int OTHER_ERRORS_CHANGE_SERVICE = 1060;
	public final static int WRONG_SERVICEVALUE_FORMAT = 1070;
	public final static int NO_CREDIT_LIMIT = 1080;
	
	//RIM Range of errors
	public final static int WRONG_SERVICENAME_FORMAT = 3000;
	
	//IN Range of errors
	public final static int OTHER_ERRORS_IN = 4000;
	public final static int WRONG_DAVALUE_FORMAT = 4010;
	public final static int ERROR_CHECKING_SUB_BALANCE = 4020;
	public final static int ERROR_NO_AMT_TO_DEDUCT = 4030;
	public final static int OTHER_ERRORS_IN_DEDUCTION = 4000;
	
	//Local Database Errors
	public final static int SUBSCRIBER_NOT_IN_DB = 5000;
}
