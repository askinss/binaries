package com.vasconsulting.www.utility;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5
{
  public static String getDigest(String password)
  {
    byte[] defaultBytes = password.trim().getBytes();
    MessageDigest algorithm;
    StringBuffer hexString = new StringBuffer();
	try {
		algorithm = MessageDigest.getInstance("MD5");
	
    algorithm.reset();
    algorithm.update(defaultBytes);
    byte[] messageDigest = algorithm.digest();
    
    for (int i = 0; i < messageDigest.length; ++i)
      hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
	
	} catch (NoSuchAlgorithmException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    return hexString.toString();
  }   
}
