package com.vasconsulting.www.utility;

import org.springframework.core.task.TaskExecutor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;

public class EmailTaskExecutor
{
	private JavaMailSenderImpl mailSender;
	private SimpleMailMessage mailMessage;
	private TaskExecutor taskExecutor;
	
	public void setMailSender(JavaMailSenderImpl mailSender)
	{
		this.mailSender = mailSender;
	}
	public void setMailMessage(SimpleMailMessage mailMessage)
	{
		this.mailMessage = mailMessage;
	}
	public void setTaskExecutor(TaskExecutor taskExecutor)
	{
		this.taskExecutor = taskExecutor;
	}
	
	private class MailSenderTaskImpl implements Runnable {
		private String message;
		
		public MailSenderTaskImpl(String message)
		{
			this.message = message;
		}
		public void run()
		{
			mailMessage.setText(this.message);
			mailSender.send(mailMessage);	
		}
	}
	
	public void sendQueuedEmails(String messageText)
	{
		taskExecutor.execute(new MailSenderTaskImpl(messageText));
	}
}
