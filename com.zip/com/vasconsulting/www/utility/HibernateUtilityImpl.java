/**
 * This is the data access service layer of the application. This class is responsible for all database access functions.
 * It currently connects to the local database system and also connects to the TABS database that is used to load subscriber credit limit.
 * @author nnamdi Jibunoh
 * @date 8-8-2011
 */
package com.vasconsulting.www.utility;

import java.util.ArrayList;
import java.util.Collection;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vasconsulting.www.domain.ActivityLogger;
import com.vasconsulting.www.domain.SubscriberDetail;
import com.vasconsulting.www.domain.TransactionLog;
import com.vasconsulting.www.interfaces.HibernateUtility;

@Repository
@Transactional
public class HibernateUtilityImpl implements HibernateUtility
{
	private SessionFactory sessionFactory;
	private SessionFactory sessionFactoryTabs;
	
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		this.sessionFactory = sessionFactory;
	}
	
	@Autowired
	public void setSessionFactoryTabs(SessionFactory sessionFactoryTabs)
	{
		this.sessionFactoryTabs = sessionFactoryTabs;
	}
	
	public int saveSubscriber(SubscriberDetail subscriberDetail)
	{
		sessionFactory.getCurrentSession().save(subscriberDetail);		
		return 0;
	}
	
	public int saveTransactionlog(TransactionLog transactionLog)
	{
		this.sessionFactory.getCurrentSession().save(transactionLog);		
		return 0;
	}
	
	@SuppressWarnings("unchecked")
	public Collection<TransactionLog> getSubscriberTransactionLog(String msisdn)
	{
		return this.sessionFactory.getCurrentSession().createQuery("from TransactionLog where msisdn = :msisdn order by date_created desc")
		.setString("msisdn", msisdn)
		.list();
	}

	@SuppressWarnings("unchecked")
	public Collection<SubscriberDetail> getSubscriberInformation(
			SubscriberDetail subscriberDetail)
	{
		return this.sessionFactory.getCurrentSession().createQuery("from SubscriberDetail where msisdn = :msisdn")
		.setString("msisdn", subscriberDetail.getMsisdn())
		.list();
	}

	public String getSubscriberTABSCreditLimit(String msisdn)
	{
		@SuppressWarnings("unchecked")
		Collection<String> response = this.sessionFactoryTabs.getCurrentSession().
		createSQLQuery("select credit_limit from POST_SUBS_PROFILE where subno = :msisdn")
		.setString("msisdn", stripLeadingMsisdnPrefix(msisdn)).list();
		
		if (response.iterator().hasNext())
			return response.iterator().next();
		else return null;
	}
	
	private String stripLeadingMsisdnPrefix(String msisdn){
		String Msisdn = msisdn;
		if (msisdn.startsWith("0")){
			return Msisdn.substring(1, Msisdn.length());
		}
		else if (Msisdn.startsWith("234")){
			return Msisdn.substring(3, Msisdn.length());
		}
		else if(Msisdn.startsWith("+234")){
			return Msisdn.substring(4, Msisdn.length());
		}
		else return Msisdn;
	}

	public int updateSubscriberDetail(SubscriberDetail subscriebrDetail)
	{
		this.sessionFactory.getCurrentSession().update(subscriebrDetail);
		return 0;
	}

	@SuppressWarnings("unchecked")
	public Collection<SubscriberDetail> loadAllSubscriberDetails()
	{
		return this.sessionFactory.getCurrentSession().createQuery("from SubscriberDetail where postpaidSubscriber = 1").list();
	}

	@SuppressWarnings("unchecked")
	public Collection<SubscriberDetail> loadAllSubscriberDetailsDueForActivation()
	{
		return this.sessionFactory.getCurrentSession().createQuery("from SubscriberDetail where postpaidSubscriber = 1 and " +
				"statusid != 'Active'").list();
	}

	@SuppressWarnings("unchecked")
	public SubscriberDetail getSubscriberInformation(String param,	String paramValue)
	{
		System.out.println("from SubscriberDetail where "+param+" = :paramValue, "+paramValue);
		Collection<SubscriberDetail> subs = this.sessionFactory.getCurrentSession().
		createQuery("from SubscriberDetail where "+param+" = :paramValue").
		setString("paramValue", paramValue).
		list();
		
		if (subs.iterator().hasNext())
			return subs.iterator().next();
		else return null;
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<SubscriberDetail> getSubscribersExpiringSoon(int noOfDays)
	{
		System.out.println("Notification day is = "+noOfDays);
		
		String requestQuery = "from SubscriberDetail where statusid = 'Active' and trunc(current_date+ :noOfDays)  = " +
		"trunc(next_subscription_date)";
		
		System.out.println("Query is = "+requestQuery);
		
		ArrayList<SubscriberDetail> subs = (ArrayList<SubscriberDetail>)this.sessionFactory.getCurrentSession().
		createQuery(requestQuery).setInteger("noOfDays", noOfDays).list();
				
		
		if (subs.isEmpty())
		{
			return new ArrayList<SubscriberDetail>();
		}
		else return subs;
	}

	public int logService(ActivityLogger logger)
	{
		this.sessionFactory.getCurrentSession().save(logger);
		return 0;
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<SubscriberDetail> getActivationReportTabular(int daysToRetrieve)
	{
		ArrayList<SubscriberDetail> queryResult = new ArrayList<SubscriberDetail>();
		
		if (daysToRetrieve == 1)
			queryResult = (ArrayList<SubscriberDetail>)this.sessionFactory.getCurrentSession().
			getNamedQuery("com.vas.domain.SubscriberDetail.GetDailyFreshActivationQuery").
			list();
		else
			queryResult = (ArrayList<SubscriberDetail>)this.sessionFactory.getCurrentSession().
			getNamedQuery("com.vas.domain.SubscriberDetail.GetAllFreshActivationQuery").
			setInteger("noOfDaysBack", daysToRetrieve).
			list();				
		
		return queryResult;
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<SubscriberDetail> getRenewalReportTabular()
	{
		ArrayList<SubscriberDetail> queryResult = new ArrayList<SubscriberDetail>();
		
		queryResult = (ArrayList<SubscriberDetail>)this.sessionFactory.getCurrentSession().
		getNamedQuery("com.vas.domain.SubscriberDetail.GetDailyRenewalsQuery").
		list();
		
		return queryResult;
	}
	
	@SuppressWarnings("unchecked")
	public int getReportSumation(String columnName, int daysToRetrieve)
	{
		ArrayList<Integer> queryResult = new ArrayList<Integer>();
		
		if (columnName.equalsIgnoreCase("date_created"))
		{
			if (daysToRetrieve == 1)
			{
				queryResult = (ArrayList<Integer>)this.sessionFactory.getCurrentSession().
				getNamedQuery("com.vas.domain.SubscriberDetail.GetDailyActivationsSumationQuery").
				list();
			}
			else
			{
				queryResult = (ArrayList<Integer>)this.sessionFactory.getCurrentSession().
				getNamedQuery("com.vas.domain.SubscriberDetail.GetAllActivationsSumationQuery").
				setInteger("noOfDaysBack", daysToRetrieve).				
				list();
			}
		}
		else
		{
			queryResult = (ArrayList<Integer>)this.sessionFactory.getCurrentSession().
			getNamedQuery("com.vas.domain.SubscriberDetail.GetDailyRenewalsQuery").
			list();
		}	
		
		if (queryResult.isEmpty()) return 0;
		else return queryResult.size();
	}
	
}
